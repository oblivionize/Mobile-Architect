package com.zybooks.project2;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditDataActivity extends AppCompatActivity {

    //Declaring my buttons and edittexts
    private Button saveButton, deleteButton;
    private EditText textEdit;

    //Declaring the database
    InventoryDatabase mInventoryDatabase;

    //declaring some variables
    private String selectedName, selectedQuantity;
    private int selectedID;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_data);

        //setting views equal to some variable names
        saveButton = findViewById(R.id.Save);
        deleteButton = findViewById(R.id.Delete);
        textEdit = findViewById(R.id.EditText);
        mInventoryDatabase = new InventoryDatabase(this);

        //get extra intents from inventory activity
        Intent receivedIntent = getIntent();

        //set extra intents equal to some variables to be used later
        selectedID = receivedIntent.getIntExtra("id", -1);
        selectedName = receivedIntent.getStringExtra("name");
        selectedQuantity = receivedIntent.getStringExtra("quantity");

        //set text equal to the current quantity
        textEdit.setText(selectedQuantity);

        //click function for save button... this doesn't work :(
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get text in the textbox
                String quantity = textEdit.getText().toString();
                //if quantity is not empty and is not equal to the current quantity
                if (quantity != null && quantity != selectedQuantity){
                    //update the quantity
                    mInventoryDatabase.updateQuantity(selectedID, selectedQuantity);

                }
            }
        });

        //click function for delete button
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get text in the textbox
                String product = textEdit.getText().toString();
                //if entry is not empty, delete the database row
                if (product != null){
                    mInventoryDatabase.deleteEntry(selectedID);
                    toastMessage("Entry Deleted");
                    goBack(v);
                }
            }
        });
    }

    //toast function
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    //function to start inventory activity
    private void goBack(View view){
        Intent intent = new Intent( this, InventoryActivity.class);
        startActivity(intent);
    }


}
