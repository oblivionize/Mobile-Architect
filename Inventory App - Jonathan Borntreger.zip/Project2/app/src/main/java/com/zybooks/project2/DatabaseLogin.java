package com.zybooks.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseLogin extends SQLiteOpenHelper {


    //Declare database name
    private static final String DATABASE_NAME = "logins.db";


    //constructor
    public DatabaseLogin(Context context){
        super(context, DATABASE_NAME,null,1);
    }

    //class for my database table
    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL1 = "_id";
        private static final String COL2 = "Username";
        private static final String COL3 = "Password";
    }

    //oncreate function
    @Override
    public void onCreate(SQLiteDatabase db){
        //create database table
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL1 + "_id integer primary key autoincrement, "+
                LoginTable.COL2 + " text, " +
                LoginTable.COL3 + " text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1){
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);
    }

    //function to add  data to my table
    public long addData(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        //put username and password into col2 and col3
        ContentValues contentValues = new ContentValues();
        contentValues.put(LoginTable.COL2, username);
        contentValues.put(LoginTable.COL3, password);

        //insert row into database
        long loginId = db.insert(LoginTable.TABLE, null, contentValues);
        return loginId;
    }

    //function to make sure username and password match
    public boolean CheckDatabaseUsername(String username, String Password) {
        SQLiteDatabase db = getReadableDatabase();

        //select row where user name and password are the rightvalues
        String sq1 = "select * from " + LoginTable.TABLE + " where username =?" + " AND "  + " Password =?";


        Cursor cursor = db.rawQuery(sq1, new String[] {username, Password});
        boolean hasObject = false;
        if(cursor.moveToFirst()){
            hasObject = true;
            int count = 0;
            while(cursor.moveToNext()){
                count++;
            }
        }

        cursor.close();
        db.close();
        return hasObject;
    }




}


