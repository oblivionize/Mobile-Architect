package com.zybooks.project2;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {

    private static final String TAG = "InventoryActivity";
    //declaring elements in the layout
    InventoryDatabase mInventoryDatabase;
    private Button addButton;
    private EditText productName, productAmount;
    private ListView mListView;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        //giving variable names to my layout elements
        EditText product = findViewById(R.id.itemName);
        EditText amount = findViewById(R.id.itemQuantity);
        Button addButton = findViewById(R.id.itemAdd);
        mListView = findViewById(R.id.listView);

        //Accessing database and updating my listview
        mInventoryDatabase = new InventoryDatabase(this);
        ArrayList<String> list = new ArrayList<>();
        UpdateListView();



        //Click method for add button
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //retrieve values in the two edit texts
                String productEntry = product.getText().toString();
                String amountEntry = amount.getText().toString();

                //if both contain entries add the data and update the list view
                if (productEntry.length() != 0 && amountEntry.length() != 0){
                    AddData(productEntry, amountEntry);
                    product.setText("");
                    amount.setText("");
                    UpdateListView();
                }
                //Display message otherwise
                else toastMessage("Please make sure both fields are filled");
            }
        });
    }

    //toast message function
    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    //function to add data to the database
    public void AddData (String newProduct, String newQuantity){
        //call addData function to add data to the database
        long insertData = mInventoryDatabase.addData(newProduct, newQuantity);

        //if statement to make sure data was added correctly
        if(insertData != -1){
           toastMessage("Data added");
        }
        else toastMessage("Error when adding data");
    }


    public void UpdateListView() {
        //get data, put into list
        Cursor data = mInventoryDatabase.getData();
        ArrayList<String> list = new ArrayList<>();
        while(data.moveToNext()) {
                //get the name of the product and the quantity
                String name = data.getString(1);
                int quantity = data.getInt(2);

                //format the name and quantity to be displayed
                String entry = "Product: " + name + " Quantity: " +quantity;

                //add entry to the list
                list.add(entry);
        }
        //adapter
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, list);
        mListView.setAdapter(adapter);

        //on click for the listview
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //retrieve name of row that was clicked
                String product = parent.getItemAtPosition(position).toString();
                //Split the string into elements since I made it all one string
                String[] elements = product.split(" ");
                //set product equal to the name of the product that I clicked on
                product = elements[1];
                String quantity = elements[3];
                Log.d(TAG, "onItemClick: The product is: " + product);
                Log.d(TAG, "onItemClick: The quantity is: " + quantity);

                int itemID = -1;
                //Retrieve item ID for editing
                itemID = mInventoryDatabase.getItemID(product);
                Log.d(TAG, "ID: " + itemID);

                //put extra and start new edit activity
                if (itemID > -1) {
                    Intent editScreenIntent = new Intent(InventoryActivity.this, EditDataActivity.class);
                    editScreenIntent.putExtra("id", itemID);
                    editScreenIntent.putExtra("name", product);
                    editScreenIntent.putExtra("quantity", quantity);
                    startActivity(editScreenIntent);

                }

            }
        });
    }

    public void goToSettings( View view){
        Intent intent = new Intent( this, SettingsActivity.class);
        startActivity(intent);
    }



}
