package com.zybooks.project2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    //declaring some stuff
    private static final String TAG = "LoginActivity";
    DatabaseLogin mDatabaseLogin;
    private Button loginButton, newUserButton;
    private EditText username, password;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //set variable names to my buttons and edit texts from the view
        EditText username = findViewById(R.id.UsernameEditText);
        EditText password = findViewById(R.id.PasswordEditText);
        Button loginButton = findViewById(R.id.buttonLogin);
        Button newUserButton = findViewById(R.id.buttonLoginNewUser);
        mDatabaseLogin = new DatabaseLogin(this);

        //on click listener for new login
        newUserButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                String usernameEntry = username.getText().toString();
                String passwordEntry = password.getText().toString();

                //if username is not null and password is not null add to the database
                if (usernameEntry.length() != 0 && passwordEntry.length() != 0){
                    AddData(usernameEntry, passwordEntry);
                    username.setText("");
                    password.setText("");
                }
            }
        });
        //on click listener for login
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String usernameEntry = username.getText().toString();
                String passwordEntry = password.getText().toString();

                //call function to check for username and password
                boolean value= mDatabaseLogin.CheckDatabaseUsername(usernameEntry, passwordEntry);

                // if value is true go to inventory activity
                if(value) {
                    goToInventory(v);
                }
                //print error message
                else toastMessage("Incorrect Username or Password");
            }

        });
    }

    private void toastMessage(String message){
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }
    //function to add data to the database
    public void AddData (String newUsername, String newPassword){
        //add data to database
        long insertData = mDatabaseLogin.addData(newUsername, newPassword);

        //error checking
        if(insertData != -1){
            toastMessage("Data added");
        }
        else toastMessage("Error when adding data");
    }

    //function to start inventory activity
    public void goToInventory( View view){
        Intent intent = new Intent( this, InventoryActivity.class);
        startActivity(intent);
    }
}