package com.zybooks.project2;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class InventoryDatabase extends SQLiteOpenHelper {

    //delcaring some variables
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;

    //constructor
    public InventoryDatabase(Context context){
        super(context, DATABASE_NAME,null,VERSION);
    }

        // table headers
        private static final String TABLE = "products";
        private static final String COL0 = "_id";
        private static final String COL1 = "product";
        private static final String COL2 = "quantity";


    @Override
    public void onCreate(SQLiteDatabase db){

        //create table for inventory
        db.execSQL("create table " + TABLE + " (" +
                COL0 + " integer primary key autoincrement, " +
                COL1 + " text, " +
                COL2 + " text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1){
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);
    }

    //function to add data to the table
    public long addData(String product, String amount){
        SQLiteDatabase db = this.getWritableDatabase();

        //put product and amount into col2 and col3
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, product);
        contentValues.put(COL2, amount);

        //insert row into database
        long InventoryId = db.insert(TABLE, null, contentValues);
        return InventoryId;
    }

    //get data function that returns cursor so we can loop through the database
    public Cursor getData(){
        SQLiteDatabase db = this.getReadableDatabase();
        String sq1 = "select * from " + TABLE;
        Cursor data = db.rawQuery(sq1,null);
        return data;
    }

    //function to get an item id from it's name
    @SuppressLint("Range")
    public int getItemID(String name){
        SQLiteDatabase db = this.getWritableDatabase();
        int id = -1;
        //query that finds id based on name
        String sql = "select _id from " + TABLE + " where product = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { name });
        if (cursor.moveToFirst()) {
            id = cursor.getInt(cursor.getColumnIndex("_id"));
        }
        //return id
        return id;

    }

    //function to update quantity
    public void updateQuantity(int id, String newQuantity){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(COL2, newQuantity);
        //update quantity where id = the passed id
        db.update(TABLE, cv, COL0 + "=?",
                new String[]{Integer.toString(id)});
    }

    //function to delete entry
    public void deleteEntry(int id){
        SQLiteDatabase db = this.getWritableDatabase();
        //query that deletes row where id equals the passed id
        String Query = "DELETE FROM " + TABLE + " WHERE " + COL0 + " = '" +
                id + "'";
        db.execSQL(Query);
    }
}
